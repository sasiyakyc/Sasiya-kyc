# SASIYA KYC VERIFICATION (Render-ready)

## Logos guaranteed
- Default logos are embedded as base64 SVG placeholders (always visible)
- Your **ImgBB links** are pre-filled in `script.js`
- The site automatically resolves ImgBB page links to a direct image URL using `og:image` (via `https://r.jina.ai/` proxy) so logos should display.

## Render deploy
Static Site:
- Build Command: (empty)
- Publish Directory: `.`

## Contacts
Edit `script.js` to add WhatsApp/Telegram links.
